

<?php $__env->startSection('content'); ?>
    <h1>Lista de Ordenes</h1>
    <?php if(empty($orders)): ?>
        <div class="alert alert-warning">
            La lista de productos está vacía.
        </div>
    <?php else: ?>
        <div class="table-responsive-md">
            <table class="table table-responsive table-striped align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Total</th>       
                        <th>Status</th>
                        <th>Fecha </th>
                        <th>Acciones </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($order->id); ?></td>
                        <td><?php echo e($order->payment->amount); ?></td>
                        <td><?php echo e($order->status); ?></td>
                        <td><?php echo e($order->updated_at); ?></td>
                        <td>
                          <a class="btn btn-primary"s href="">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye-fill" viewBox="0 0 16 16">
                          <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z"/>
                          <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8zm8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z"/>
                        </svg></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zabit\zabit.store\resources\views/orders_list/index.blade.php ENDPATH**/ ?>