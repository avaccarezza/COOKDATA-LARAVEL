

<?php $__env->startSection('content'); ?>
    <h1>Customer area COOKDATA</h1>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Cookdata-laravel\resources\views/customers_area/customers/cookdata.blade.php ENDPATH**/ ?>