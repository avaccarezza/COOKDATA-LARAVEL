<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="icon" href="<?php echo e(URL::asset('img/utilities/favicon.ico')); ?>"> 
    <title>Cookdata</title>
    <!-- Core Stylesheets -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('../css/carousel-slider.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('../css/about.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('../css/careers.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('../css/com-soon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('../css/contact.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('../css/faq.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('../css/news.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('../css/pricing.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('../css/project.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('../css/shop.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('../css/single-product.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('../css/team.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('../css/testimonials.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('../css/services.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('../css/styles.css')); ?>">
   
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@500" rel="stylesheet">
    <!-- Whatsapp widget -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!--Global JavaScript -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <script src="../js/jquery/jquery.min.js"></script>
    <script src="../js/popper/popper.min.js"></script>
    <script src="../js/bootstrap/bootstrap.min.js"></script>
    <script src="../js/custom.js"></script>
    <script src="../js/wow/wow.min.js"></script>
    <script async src="../js/carousel-slider.js"></script>

    <!-- Plugin JavaScript -->
    <script src="../js/jquery-easing/jquery.easing.min.js"></script>
<?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
<!--JS Form -->
<script async src="../js/jquery.validate.min.js"></script>
<script async src="../js/main.js"></script>
<script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.12.0/dist/cdn.min.js"></script>
</head>
<body>

    <div id="app">
        <?php if(Request::is('/')): ?>
        <nav class="navbar navbar-expand-md navbar-light  shadow-sm p-0 d-none d-md-block position-relative z-3" style="background-color: #F0F0F0;" >
            <div class="container">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link text-dark" href="mailto:decidecondatos@cookdata.io">decidecondatos@cookdata.io</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-dark" target="blank" href="https://wa.me/34667316307/">(+54) 11 3561 3735</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-dark" target="blank" href="https://wa.me/34667316307/">(+34) 667 316 307</a>

                    </li>
                </ul>
            </div>
        </nav>
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm z-index-3" data-toggle="affix">
            <div class="container">
                <img src="<?php echo e(URL::asset('img/utilities/headerkitdigital.png')); ?>" width="100%">
            </div>
        </nav>
        <?php endif; ?>
        
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm sticky-top">
            
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(URL::asset('img/utilities/logocookdata.png')); ?>" width="150px">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/')); ?>">Inicio</a>
                        </li>
                        <?php if(Request::is('/')): ?> 
                        <li class="nav-item">
                            <a class="nav-link" href="#servicios">Servicios</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#beneficios">Beneficios</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#clientes">Clientes</a>
                        </li>
                       
                        <li class="nav-item">
                            <a class="nav-link" href="#contacto">Contactos</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarWhiteDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                              Partners
                            </a>
                            <ul class="dropdown-menu dropdown-menu-white" aria-labelledby="navbarWhiteDropdownMenuLink">
                              <li><a class="dropdown-item" href="<?php echo e(route('partners_section.index')); ?>">Agora</a></li> 
                            </ul>
                        </li>
                       <?php endif; ?>
                    </ul>
                        <ul class="navbar-nav ms-auto">     
                    <?php if(Route::current()->getName() == 'customers_area.index'): ?> 
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            Utilidades
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <?php $__currentLoopData = Auth::user()->customer->apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if( $app->type_of_app == 'Utilidades'): ?>
                            <a class="dropdown-item d-flex justify-content-center pt-2" href="https://<?php echo e($app->path); ?>" target="blank">
                                <?php echo e($app->app); ?>

                            </a>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </div>
                    </li>
                    <!-- Right Side Of Navbar -->
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            Soporte
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <?php $__currentLoopData = Auth::user()->customer->apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if( $app->type_of_app == 'Soporte'): ?>
                            <a class="dropdown-item d-flex justify-content-center pt-2" href="https://<?php echo e($app->path); ?>" target="blank">
                                <?php echo e($app->app); ?>

                            </a>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </div>
                    </li>
                    
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            Informes
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <?php $__currentLoopData = Auth::user()->customer->apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if( $app->type_of_app == 'Informes'): ?>
                            <a class="dropdown-item d-flex justify-content-center pt-2" href="https://<?php echo e($app->path); ?>" target="blank">
                                <?php echo e($app->app); ?>

                            </a>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </div>
                    </li>
                   
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            Apps Mobile
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <?php $__currentLoopData = Auth::user()->customer->apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if( $app->type_of_app == 'Aplicaciones'): ?>
                            <a class="dropdown-item d-flex justify-content-center pt-2" href="https://<?php echo e($app->path); ?>" target="blank">
                                <?php echo e($app->app); ?>

                            </a>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                      
                    </li>
                   
                    <?php elseif(Route::current()->getName() == 'customers_area.show'): ?>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            Utilidades
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <?php
                                $customerName = request()->segment(2);
                            ?>
                            <?php $__currentLoopData = Auth::user()->customers->whereIn('customer', [$customerName])->first()->apps->where('type_of_app', 'Utilidades'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="dropdown-item d-flex justify-content-center pt-2" href="https://<?php echo e($app->path); ?>" target="blank">
                                <?php echo e($app->app); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </div>
                      
                    </li>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            Soporte
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <?php
                                $customerName = request()->segment(2);
                            ?>
                            <?php $__currentLoopData = Auth::user()->customers->whereIn('customer', [$customerName])->first()->apps->where('type_of_app', 'Soporte'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="dropdown-item d-flex justify-content-center pt-2" href="https://<?php echo e($app->path); ?>" target="blank">
                                <?php echo e($app->app); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                      
                    </li>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            Informes
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <?php
                            $customerName = request()->segment(2);
                        ?>
                        <?php $__currentLoopData = Auth::user()->customers->whereIn('customer', [$customerName])->first()->apps->where('type_of_app', 'Informes'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="dropdown-item d-flex justify-content-center pt-2" href="https://<?php echo e($app->path); ?>" target="blank">
                            <?php echo e($app->app); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                      
                    </li>
                   <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            Apps Mobile
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <?php
                                $customerName = request()->segment(2);
                            ?>
                            <?php $__currentLoopData = Auth::user()->customers->whereIn('customer', [$customerName])->first()->apps->where('type_of_app', 'Aplicaciones'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="dropdown-item d-flex justify-content-center pt-2" href="https://<?php echo e($app->path); ?>" target="blank">
                                <?php echo e($app->app); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>                    
                    </li>                   
                    <?php endif; ?>
   
                    <?php if(optional(auth()->user())->isConsultant() && Request::is('customers_area/*') ): ?>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            Clientes
                        </a>
                        <div class="dropdown-menu dropdown-menu-end"  aria-labelledby="navbarDropdown">
                            
                            <?php $__currentLoopData = Auth::user()->customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="dropdown-item d-flex justify-content-center pt-2" href="<?php echo e(route('customers_area.show',  $customer->customer)); ?>"   >
                                    <?php echo e($customer->customer); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>
                    </li>     
                   <?php endif; ?>
                    
                        <?php if(optional(auth()->user())->isConsultant() && !Request::is('customers_area/*') ): ?> 
                        <li class="nav-item">
                            <?php $__currentLoopData = Auth::user()->customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="nav-link" href="<?php echo e(route('customers_area.show', $customer->customer)); ?>" >Area de consultores</a>
                            <?php break; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </li>
                    <?php elseif(optional(auth()->user())->isUser() && !Request::is('customers_area') ): ?> 
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('customers_area.index')); ?>" >Area de clientes</a>
                        </li>
                         
                        
                    <?php endif; ?>
                    <!--1- funcion del IF:  muestra el elemento de Panel si el usuario es Admin
                        2- optional() es un helper, que si auth()->user() retorna null la funcion isAdmin() nunca es llamada   --> 
                        <?php if(optional(auth()->user())->isAdmin()): ?>  
                       
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('users.index')); ?>" >Panel</a>
                        </li>
                        <?php endif; ?>
                        
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Iniciar sesión')); ?></a>
                                </li>
                            <?php endif; ?>

                            
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                  
                                    Mi Perfil
                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <div class="card flex-row"><img class="card-img-left example-card-img-responsive rounded-circle m-2" src="<?php echo e(asset(Auth::user()->profile_image)); ?>" alt="<?php echo e(Auth::user()->name); ?>" width="96" height="96"/>
                                        <div class="card-body">
                                          <h4 class="card-title h5 h4-sm"><?php echo e(Auth::user()->name); ?></h4>
                                          <p class="card-text"><?php echo e(Auth::user()->email); ?></p>
                                          <a href="<?php echo e(route('profile.index')); ?>">
                                            <button type="submit" class="btn btn-warning">
                                                <?php echo e(__('Ver perfil')); ?>

                                            </button>
                                            </a>
                                        </div>
                                    </div>
                                        <a class="dropdown-item d-flex justify-content-center pt-2" href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();">
                                            <button type="submit" class="btn btn-warning">                                        
                                            <?php echo e(__('Cerrar Sesión')); ?>

                                            </button>
                                        </a>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
<?php if (! (Request::is('/') || Request::is('customers_area') || Request::is('customers_area/*') ||  Request::is('panel') )): ?>
        <main class="py-4">
            <div class="container-fluid">
                <?php endif; ?>
                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if(isset($errors) && $errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
                </div>
        </main>
    <?php if (! (Request::is('/'))): ?>
    </div>
    <?php endif; ?>
 <!--====================================================
                      FOOTER
======================================================-->
<footer >
    <div id="footer-s1" class="footer-s1">
        <div class="footer">
            <div class="container">
                <div class="row">
                    <!-- About Us -->
                    <div class="col-md-3 col-sm-6">
                        <div>
                            <a href="#topmenu" class="smooth-scrolls">
                                <img src="<?php echo e(URL::asset('img/utilities/logo-transparente.png')); ?>" alt="" class="img-fluid">
                            </a>
                        </div>
                    </div>
                    <!-- End About Us -->

                    <!-- Recent News -->
                    <div class="col-md-3 col-sm-6">
                        <div class="heading-footer">
                            <h2>Links útiles</h2>
                        </div>
                        <ul class="list-unstyled link-list">
                            <li>
                                <a class="smooth-scrolls" href="<?php echo e(url('/')); ?>">Inicio</a>
                                <i class="fa fa-angle-up"></i>
                            </li>
                            <?php if(Request::is('/')): ?> 
                            <li>
                                <a class="smooth-scrolls" href="#servicios">Servicios</a>
                                <i class="fa fa-angle-up"></i>
                            </li>
                            <li>
                                <a class="smooth-scrolls" href="#clientes">Clientes</a>
                                <i class="fa fa-angle-up"></i></i>
                            </li>
                            <li>
                                <a class="smooth-scrolls" href="#beneficios">Beneficios</a>
                                <i class="fa fa-angle-up"></i>
                            </li>
                            <li>
                                <a class="smooth-scrolls" href="#contacto">Contacto</a>
                                <i class="fa fa-angle-up"></i>
                            </li>
                            <li>
                                <a href="#" data-toggle="modal" data-target="#login-modal">Area de Clientes</a>
                            </li>
                            <?php endif; ?>
                            <!-- <li><a href="#">Business Intelligence</a><i class="fa fa-angle-right"></i></li>  hay que arreglar link cuando esté la página -->
                            <!-- <li><a href="#">Contáctanos</a><i class="fa fa-angle-right"></i></li>  -->
                        </ul>
                    </div>
                    <!-- End Recent list -->

                    <!-- Latest Tweets -->
                    <div class="col-md-3 col-sm-6">
                        <div class="heading-footer">
                            <h2>Contáctanos</h2>
                        </div>
                        <address class="address-details-f">
                            <b>España</b><br>
                            Av Condesa de Chinchon, 11<br>
                            28660 Boadilla del Monte<br>
                            Madrid<br>
                            <i class="fa fa-phone"></i> (+34) 667 316 307<br>
                            <i class="fa fa-envelope-o"></i> <a href="mailto:decidecondatos@cookdata.io"
                                class="">decidecondatos@cookdata.io</a>
                        </address>
                        <ul class="list-inline social-icon-f top-data">
                        </ul>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="heading-footer-invisible">
                            <h2><br></h2>
                        </div>
                        <address class="address-details-f">
                            <b>Argentina</b><br>
                            Las Camelias 3324<br>
                            1669 - Pilar<br>
                            Buenos Aires<br>
                            <i class="fa fa-phone"></i> (+54) 11 3561 3735<br>
                            <i class="fa fa-envelope-o"></i> <a href="mailto:decidecondatos@cookdata.io"
                                class="">decidecondatos@cookdata.io</a>
                        </address>
                        <ul class="list-inline social-icon-f top-data">
                        </ul>
                    </div>
                    <!-- End Latest Tweets -->
                </div>
            </div>
            <!--/container -->
        </div>
    </div>

    <div id="footer-bottom">
        <div class="container ">
            <div class="row">
                <div class="col-md-12">
                    <div id="footer-copyrights">
                        <p>Copyright &copy; 2021 All Rights Reserved by Cookdata.</br><a
                                href="<?php echo e(route('politics.index')); ?>">Privacy Policy</a> <a
                                href="<?php echo e(route('terms.index')); ?>">Terms of Services</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- <a href="#home" id="back-to-top" class="btn btn-sm btn-green btn-back-to-top smooth-scrolls hidden-sm hidden-xs" title="home" role="button">
    <i class="fa fa-angle-up"></i>
</a> -->
</footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Cookdata-laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>