<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Panel de administración')); ?></div>

                <div class="card-body">
                   
                    <div class="d-flex justify-content-between">
                        <div class="">
                            <a type="button" class="btn btn-dark " href="<?php echo e(route('products.index')); ?>">Administrar productos</a>
                        </div>
                        <div class="">
                            <a type="button" class="btn btn-dark " href="<?php echo e(route('products.index')); ?>">Administrar puntos</a>
                        </div>
                        <div class="">
                            <a type="button" class="btn btn-dark " href="<?php echo e(route('products.index')); ?>">Administrar locales</a>
                        </div>
                        
                        <div class="">
                            <a type="button" class="btn btn-dark " href="<?php echo e(route('profile.index')); ?>">Administrar perfil</a>
                        </div>
                      </div>
                      
                      
                      
                        
                </div>
                </div>
            </div>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zabit\zabit.store\resources\views/panel.blade.php ENDPATH**/ ?>