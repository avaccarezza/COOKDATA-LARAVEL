
<?php $__env->startSection('content'); ?>
<section id="about" class="career-p1 about">
    <!-- titulo -->
    <div class="container">
        <div class="row title-bar">
            <div class="col-md-12">
                <h1 class="wow fadeInUp">TÉRMINOS Y CONDICIONES DE USO DEL SITIO</h1>
                <div class="heading-border"></div>
                <p class="wow fadeInUp" data-wow-delay="0.4s">
                    <h2><b>última actualización: agosto 2022</b></h2>
                    </br>
                    </br>
                    <h2>CONDICIONES DE USO LEGAL</h2>
                </br>
                   Titular: Cookdata Tech, S.L.
                </br>
                    NIF: B02854172
                </br>
                    Domicilio Social: Calle Alcalá de Henares, 10 - 28914 Leganés - Madrid
                </br>
                    e-mail: cookdata@cookdata.io 
                </br>
                </br>
                    <h2>CONDICIONES GENERALES</h2>
                    </br>
                    
                    Los presentes términos y condiciones (en adelante, los “Términos y Condiciones”) de servicio regulan la relación contractual entre los usuarios (en adelante los “Usuarios” o el “Usuario”), con Cookdata, adelante y/o cualquiera de sus vinculadas, (en “COOKDATA”
                    y en conjunto con los Usuarios, las “Partes”). Los Usuarios se encontrarán sujetos a los Términos y Condiciones Generales respectivos, junto con todas las demás políticas y principios que rigen COOKDATA y que son incorporados al
                    presente por referencia.</br>
                    Los Usuarios entienden y aceptan que el consentimiento de los presentes Términos y Condiciones autorizan a COOKDATA y/o cualquiera de sus vinculadas a actuar conforme lo indican los presentes Términos y Condiciones de forma indistinta a efectos de poder
                    proveer el Servicio, conforme se define a continuación.</br>
                    El uso del sitio institucional de COOKDATA accesible a través de “https://www.cookdata.io/” y/o cualquier otra URL de propiedad de COOKDATA (en adelante, el “Sitio”) se encuentra sujeto a los presentes Términos y Condiciones.</br>
                    El ingreso y utilización del Sitio atribuye la condición de Usuario e implica la plena y total conformidad con los presentes Términos y Condiciones. TODO AQUEL QUE NO ACEPTE ESTOS TÉRMINOS Y CONDICIONES, LOS CUALES SON OBLIGATORIOS Y VINCULANTES, DEBERÁ
                    ABSTENERSE DE UTILIZAR EL SITIO.</br>
                    Los Usuarios afirman ser plenamente capaces y competentes para aceptar y cumplir los Términos y Condiciones, y para celebrar acuerdos jurídicamente vinculantes conforme a las leyes vigentes.</br>
                    Los presentes Términos y Condiciones podrán ser modificados y/o actualizados a exclusivo criterio de COOKDATA. Dichas modificaciones entrarán en vigor a los 10 (diez) días de publicadas en el Sitio, por lo que se aconseja a los Usuarios la revisión regular
                    de los Términos y Condiciones.</br> En caso de que un Usuario no se encontrara de acuerdo con la nueva versión de los Términos y Condiciones, deberá comunicarlo expresamente a COOKDATA dentro de los 5 (cinco)
                    días posteriores a la publicación de la misma. La falta de aceptación implicará la obligación de abstenerse de utilizar el Sitio y, en caso de corresponder, el bloqueo de la cuenta de Usuario. Transcurrido el plazo de 5 (cinco)
                    días antes mencionado, y si el Usuario no hubiera expresado disconformidad, se considerará que acepta los nuevos términos y condiciones.</br>
                    Se aclara expresamente que cualquier instrucción o aviso adicional que sea incorporado en el Sitio será considerado como parte de estos Términos y Condiciones, teniendo en consecuencia carácter obligatorio y vinculante.</br>
                    COOKDATA provee el Sitio con el fin de ofrecer al Usuario información relacionada a los servicios que COOKDATA provee tales como pero sin limitar, Data Analytics ; Data Science, Data Analytics, Desarrollo Web, Digitalización de procesos, entre otros (en
                    adelante, el “Servicio”).</br>
                    </br>
                    </br>
                    <h2>1. INFORMACIÓN DEL SITIO</h2>
                    </br>
                    <b>1.1.</b> Los presentes términos y condiciones (en adelante, los “Términos y Condiciones”) de servicio regulan la relación contractual entre los usuarios (en adelante los “Usuarios” o el “Usuario”), con COOKDATA S.A., (en adelante
                    “COOKDATA” y en conjunto con los Usuarios, las “Partes”), conforme se describe a continuación, del Sitio Web publicado en la URL: https://www.cookdata.io/ (en adelante, el “Sitio”), provista por COOKDATA (en adelante, “COOKDATA”),
                    cuya función principal consiste en ofrecer al Usuario información relacionada a los servicios que COOKDATA provee, tales como pero sin limitar, Desarrollo Web, Data Science, Data Analytics, Digitalización de procesos, entre otros
                    (en adelante, el “Servicio”). En caso de ser necesario, COOKDATA podrá complementar los términos y condiciones con información y/o términos y condiciones específicos con relación al Servicio.</br>
                    <b>1.2.</b> El mero acceso al Sitio atribuye la condición de usuario de COOKDATA (en adelante el “Usuario” o los “Usuarios”) y expresa la aceptación plena y sin reservas de todas y cada una de las cláusulas de los términos y condiciones
                    en la versión publicada por COOKDATA en el momento mismo en que el Usuario acceda al Sitio o utilice su Servicio. En consecuencia, los términos y condiciones constituirán un acuerdo válido y obligatorio entre el Usuario y COOKDATA
                    con relación a la privacidad. Asimismo, la utilización del Servicio expresa la aceptación plena y sin reservas del Usuario de los Términos y Condiciones de Utilización del Servicio (en adelante, los “Términos y Condiciones”) publicados
                    por COOKDATA en https://www.cookdata.io/terminos-condiciones, que se complementan con la Política de Privacidad.</br>
                    ANTES DE NAVEGAR Y/O UTILIZAR EL SITIO Y/O EL SERVICIO, POR FAVOR LEA ATENTAMENTE LOS PRESENTES TÉRMINOS Y CONDICIONES. SI EL USUARIO NO ESTÁ DE ACUERDO CON LOS PRESENTES TÉRMINOS Y CONDICIONES, DEBE ABSTENERSE DE UTILIZAR EL SITIO Y/O EL SERVICIO.</br>
                    </br>
                    </br>
                    <h2>2. RESPONSABLE DE TRATAMIENTO DE SUS DATOS PERSONALES</h2>
                    </br>
                    <b>2.1.</b> COOKDATA será la sociedad responsable del tratamiento de los Datos Personales que el Usuario facilite en el Sitio, o que se recopilen o procesen en el Sitio, por, para o mediante los Servicios, o en relación con ellos.</br>
                    En cualquier caso, si el titular de los Datos Personales es visitante del Sitio o Usuario del mismo, cualesquiera recopilación, uso e información compartida en relación con sus Datos Personales quedarán sujetos a estos Términos y condiciones, las Política
                    de Privacidad, la Política de Cookies complementaria y sus actualizaciones.</br>
                    <b>2.2.</b> Para COOKDATA la privacidad de los Datos Personales del Usuario es muy importante. En caso de que el Usuario tenga alguna duda acerca de los Términos y condiciones, o sobre la utilización del Sitio o el Servicio, deberá
                    ponerse en contacto con COOKDATA, en cualquier momento, enviando un correo electrónico a cookdata@cookdata.io.</br>
                    </br>
                    </br>
                    <h2>3. RECOLECCIÓN DE INFORMACIÓN DE LOS USUARIOS</h2>
                    </br>
                    <b>3.1.</b> COOKDATA trata los Datos Personales del Usuario únicamente con el consentimiento expreso que el Usuario le otorga con la aceptación de los presente términos y condiciones.</br>Asimismo, el Usuario acepta que COOKDATA
                    pueda recolectar información suya utilizando cookies y tags, así como aquella información proporcionada por el Usuario a través de los formularios del Sitio al registrarse y/o al utilizar el Servicio. En caso de que un Usuario
                    del Sitio no desee aceptar estas cookies, podrá configurar su navegador para que le otorgue la opción de aceptar cada cookie y rechazar las que no desee.</br>
                    <b>3.2.</b> Detallamos a continuación toda la información que COOKDATA recolecta: Información facilitada por el Usuario:</br>
                    i) nombre y apellido; (ii) teléfono, (iii) estado de residencia y (iii) curso; (en adelante, en su conjunto como los “Datos Personales”).</br>
                    Información recopilada pasivamente:</br>
                    Cuando el Usuario accede al Sitio y/o utiliza el Servicio COOKDATA podrá recopilar y almacenar de forma automática ciertos tipos de información, tales como la dirección del protocolo de Internet (IP) de la computadora o dispositivo del Usuario y otra
                    información técnica sobre el uso de la computadora o dispositivo, como el tipo y versión del navegador, la configuración de la zona horaria, y el sistema operativo, ubicaciones geográficas, sesiones de uso, permanencia en el Sitio,
                    frecuencia de uso, []</br>
                    Información procedente de otras fuentes: Es posible que COOKDATA reciba información del Usuario de otras fuentes tales como fuentes públicas, terceros (por ejemplo, agencias de informes del consumidor), []</br>
                    Información proveniente de cookies, tags y/o cualquier otro método de detección de información automatizada provisto por las herramientas que ofrecen en el Sitio: La información que recopile COOKDATA podrá incluir el comportamiento de navegación, dirección
                    IP, logs, y otros tipos de información. Sin embargo, COOKDATA no recolectará información personal identificable de manera directa de ningún Usuario usando cookies o tags o cualquier otro método de detección de información automatizada
                    provisto por las herramientas que ofrece el Sitio.</br>
                    </br>
                    </br>
                    <h2>4. FINALIDAD DE TRATAMIENTO DE LOS DATOS PERSONALES.</h2>
                    </br>
                    <b>4.1.</b> COOKDATA trata la información personal del Usuario para las siguientes finalidades: Autorizar y administrar su acceso al Sitio, verificar su identidad, autenticar sus visitas y proporcionarle el Servicio;</br>
                    Gestionar, analizar, desarrollar, personalizar y mejorar el Sitio y el Servicio; Proveer el Servicio y sus mejoras a los Usuarios;</br>
                    Análisis a efectos de poder brindar a los Usuarios el Servicio, y mejorar el método de pago; Enviar a sus Usuarios, notificaciones, noticias y novedades de su interés, además de aquellas que revistan el carácter de notificaciones de índole institucional
                    o legal;</br>
                    Analizar las conductas y comportamientos de los Usuarios en carácter de tales en su Sitio, a los efectos de intentar mejorar su Servicio e intentar proveerlos de mejores soluciones a sus necesidades;</br>
                    Enviar información y boletines de noticias sobre la actualidad de COOKDATA, su Servicios y eventos vía WhatsApp, teléfono, correo postal, correo electrónico, incluso cuando nuestra relación haya terminado salvo que la persona interesada manifieste lo
                    contrario;
                    </br>
                    Facilitar el cumplimiento de obligaciones legales en caso de ser solicitadas por tribunales, u organismos estatales nacionales o internacionales que así lo requieran y lo soliciten en la forma correspondiente.</br>
                    Obtener el diagnóstico de los eventuales problemas de conexión que puedan llegar a existir entre el Sitio de COOKDATA y los Usuarios, mejorando la calidad de los Servicios.</br>
                    </br>
                    </br>
                    <h2>5. USO DE LA INFORMACIÓN DE LOS USUARIOS RECOLECTADA.</h2>
                    </br>
                    <b>5.1.</b> COOKDATA utilizará y almacenará la información provista por los Usuarios y la recolectada por COOKDATA con el fin de proveer el Servicio y sus mejoras a los Usuarios, intentando ajustarse a sus necesidades, por el plazo
                    máximo que establezca la legislación aplicable.</br>
                    <b>5.2.</b> COOKDATA conservará y utilizará los Datos Personales otorgados por el Usuario durante el período en que este último utilice el Sitio y/o utilice el Servicio con la finalidad de prestar el mejor Servicio. Una vez finalizada
                    la relación entre las Partes, por el motivo que fuere, COOKDATA se reserva el derecho de conservar la información hasta finalizar la finalidad de su tratamiento. Posteriormente al plazo mencionado, COOKDATA procederá a la destrucción
                    de los Datos Personales.</br>
                    <b>5.3.</b> COOKDATA, podrá enviar a sus Usuarios, notificaciones, noticias y novedades de su interés, además de aquellas que revistan el carácter de notificaciones de índole institucional o legal a los fines de ofrecer sus Servicios,
                    ello, siempre y cuando sea aceptado por el Usuario y aquel no haya ejercido su derecho de opt-out.</br>
                    <b>5.4.</b> COOKDATA podrá compartir la información con otras empresas de servicios o sitios de internet o similares a los fines de cumplir con la finalidad del Servicio de COOKDATA y mejorar su calidad. Generalmente dichas empresas
                    o sitios de internet poseen sus propias políticas de privacidad de datos a los fines de su protección. De todas maneras, COOKDATA empeñará sus mejores esfuerzos en que la privacidad de la información compartida sea protegida de
                    la mejor manera posible. En los casos que corresponda COOKDATA intentará firmar acuerdos expresos en materia de protección de datos y de privacidad de la información. Sin perjuicio de ello, COOKDATA no será responsable por los
                    daños provocados por tales empresas y/o sitios de internet en cuanto a su deber de protección, confidencialidad y privacidad de los datos que ellas manejan.</br>
                    <b>5.5.</b> En lo que respecta al tratamiento de datos personales de ciudadanos de la Unión Europea, COOKDATA estará a los principios y obligaciones recogidas en el Reglamento UE 2016/679, del Parlamento Europeo y del Consejo,
                    de 27 de abril de 2016, relativo a la protección de las personas físicas en lo que respecta al tratamiento de datos personales y a la libre circulación de estos datos (RGPD).</br>
                    <b>5.6.</b> COOKDATA no venderá, alquilará ni negociará ningún Dato Personal a ningún tercero para fines comerciales. Cualquier persona que hubiera provisto información de contacto personal a través del Sitio de COOKDATA, podrá
                    enviar un correo electrónico a cookdata@cookdata.io a fin de actualizar, borrar y/o corregir su información personal de contacto. COOKDATA responderá dicho requerimiento dentro de las 48 (cuarenta y ocho) horas siguientes a la
                    recepción de esta vía correo electrónico.</br>
                    <b>5.7.</b> El Sitio de COOKDATA podrá contener enlaces a otros sitios de internet que no sean propiedad de COOKDATA. En consecuencia, COOKDATA no será responsable por el actuar de dichos sitios de internet, a los cuales no se
                    aplicará los Términos y condiciones. Recomendamos examinar los Términos y condiciones detallados en aquellos sitios de internet para entender los procedimientos de recolección de información que utilizan y como protegen sus datos
                    personales.
                    </br>
                    </br>
                    </br>
                    <h2>6. CESIÓN Y TRANSFERENCIA DE LOS DATOS PERSONALES.</h2>
                    </br>
                    <b>6.1.</b> Únicamente para cumplir con los fines establecidos en los presente términos y condiciones y a efectos de prestar el Servicio, COOKDATA podrá revelar los Datos Personales y/o información personal del Usuario, cuando
                    sea necesario, a las autoridades, los socios de COOKDATA y otros terceros, como terceros proveedores de servicios utilizados en relación con el Servicio, por ejemplo para realizar servicios de marketing, publicidad, comunicación,
                    infraestructuras y servicios de TI, para personalizar y mejorar nuestro Servicio, para procesar las transacciones con tarjetas de crédito u otros métodos de pago. Cuando COOKDATA contratare a un proveedor de servicios le proporcionará
                    la información que necesitará para realizar su función específica, que puede incluir Datos Personales y otra información que el Usuario proporcione a través del Sitio. Estos proveedores de servicio están autorizados a utilizar
                    los Datos Personales sólo cuando sea necesario para proporcionar sus servicios.</br>
                    <b>6.2.</b> En algunos casos, como la República Argentina o la República Oriental del Uruguay la información personal puede transferirse fuera del país a países con los mismos o mejores niveles de protección. En caso de que la
                    información personal se transfiera a países con niveles más bajos de protección, COOKDATA realizará esas transferencias sujetas a las salvaguardas y medidas de seguridad adecuadas, como las cláusulas estándar de protección de datos
                    adoptadas en los respectivos acuerdos o aprobadas por la autoridad legal aplicable.</br>
                    <b>6.3.</b> A su vez, COOKDATA podrá compartir los Datos Personales de los Usuarios con terceros, con el consentimiento previo y expreso del Usuario.</br>
                    <b>6.4.</b> En lo que respecta al tratamiento de datos personales de ciudadanos de la Unión Europea (UE) y/o Espacio Económico Europeo, se informa que:</br>
                    (i) COOKDATA podrá transferir los datos personales de los Usuarios del Sitio y los que se generen, en su caso, al utilizar el Sitio y/o el Servicio a entidades situadas en el territorio de la República Argentina, siendo éste, un país declarado por la
                    Comisión Europea de nivel de protección adecuada conforme a su Decisión 2003/490/CE, de 30 de junio de 2003.</br>
                    (ii) COOKDATA podrá transferir los referidos Datos Personales a otras entidades situadas en terceros países que hayan sido declarados por la Comisión Europea de nivel de protección adecuada o con las que se hayan suscrito acuerdos con las garantías adecuadas
                    impuestas por las autoridades europeas (ejemplo, Cláusulas tipo de protección de datos adoptadas por la Comisión, etc.)</br>
                    </br>
                    </br>
                    <h2>7. CONFIDENCIALIDAD Y SEGURIDAD DE LA INFORMACIÓN.</h2>
                    </br>
                    <b>7.1.</b> COOKDATA ha adoptado medidas de seguridad razonables para proteger la información de los Usuarios e impedir el acceso no autorizado a sus datos o cualquier modificación, divulgación o destrucción no autorizada de los
                    mismos. La información recolectada por COOKDATA, será mantenida de manera estrictamente confidencial. El acceso a los datos personales está restringido a aquellos empleados, contratistas, operadores, y representantes de COOKDATA
                    que necesitan conocer tales datos para desempeñar sus funciones y desarrollar o mejorar nuestro Servicio. COOKDATA exige a sus proveedores los mismos estándares de confidencialidad. COOKDATA no permite el acceso a esta información
                    a terceros ajenos a COOKDATA, a excepción de un pedido expreso del Usuario.</br>
                    <b>7.2.</b> Sin perjuicio de lo expuesto, considerando que internet es un sistema abierto, de acceso público, COOKDATA no puede garantizar que terceros no autorizados no puedan eventualmente superar las medidas de seguridad y utilizar
                    la información de los Usuarios en forma indebida. En todo caso, COOKDATA mantiene planes de seguridad y de respuesta a incidentes para controlar incidentes relacionados con el acceso no autorizado a la información privada que recopila
                    o almacena.</br>
                    </br>
                    </br>
                    <h2>8. CAMBIOS EN LA ESTRUCTURA CORPORATIVA.</h2>
                    </br>
                    <b>8.1.</b> COOKDATA se reserva el derecho de transferir la información recolectada en caso de venta o fusión de COOKDATA, o de una adquisición de los activos principales de COOKDATA, o cualquier otra clase de transferencia de
                    COOKDATA a otra entidad. En dicho supuesto, COOKDATA deberá adoptar las medidas razonables a efectos de asegurar que dicha información sea utilizada de una manera consistente con los términos y condiciones.</br>
                    </br>
                    </br>
                    <h2>9. MENORES DE EDAD</h2>
                    </br>
                    <b>9.1.</b> Si bien el Sitio y/o Servicio no están dirigidos a menores de edad, en caso en que algún menor tenga acceso a los mismos, su uso deberá ser supervisado por los padres, madres, tutores o responsables legales. El Sitio
                    y/o Servicio están permitidos sólo para quienes tengan edad legal para contratar y no se encuentren inhibidos legalmente o de algún modo vedados de ejercer actos jurídicos, derechos y/u obligaciones. Habida cuenta de ello, los
                    menores de 18 años no tienen permitido el ingreso al Sitio y/o Servicio, así como tampoco suministrar ningún Dato Personal, ni ningún otro tipo de información.</br>
                    <b>9.2.</b> Asimismo, toda vez que los menores de edad pueden no alcanzar a comprender debidamente los términos y condiciones y sus implicancias, ni decidir válidamente sobre las opciones disponibles a través de sus Servicios,
                    COOKDATA insta a todos los padres, madres, tutores o responsables legales, bajo cuya supervisión se encuentren los menores que accedan al Servicio de COOKDATA, a participar activa y cuidadosamente en las actividades que el menor
                    realice en internet o través del Sitio, al Servicio on-line que utilicen dichos menores, a la información a la que estos accedan, ya sea cuando dichos menores visiten el Sitio de COOKDATA o cualquier otro sitio de terceros, a enseñarles
                    y a guiarlos en cómo proteger su propia información personal mientras estén navegando en internet.</br>
                    </br>
                    </br>
                    <h2>10. DERECHOS DE LOS USUARIOS SOBRE LA INFORMACIÓN.</h2>
                    </br>
                    <b>10.1.</b> COOKDATA tratará, por todos los medios a su alcance, de facilitar a los Usuarios sobre los cuales haya recopilado o almacenado información personal, el acceso a sus Datos Personales (“Derecho de Acceso”), así como
                    la rectificación, modificación o actualización de los mismos (“Derecho de Rectificación”), o incluso la cancelación de dichos datos personales (“Derecho de Remoción”), a menos que COOKDATA pueda denegar dichas solicitudes (en adelante,
                    las “Solicitudes”), en caso que se encuentre obligada o tenga derecho a conservar dichos Datos de acuerdo a la legislación aplicable.</br>
                    a) A dichos efectos, el Usuario deberá enviar su Solicitud mediante el envío de un correo electrónico con el asunto “Acceso a Datos Personales” a cookdata@cookdata.io COOKDATA podrá requerir a dicho Usuario que se identifique, lo que podrá ser verificado
                    por COOKDATA, así como que precise los Datos Personales a los cuales se desea acceder, rectificar o remover.</br>
                    b) COOKDATA podrá rechazar la tramitación de Solicitudes que sean irrazonablemente repetitivas o sistemáticas, que requieran un esfuerzo técnico desproporcionado, que pongan en peligro la privacidad de los demás Usuarios, o que se consideren poco prácticas,
                    o para las que no sea necesario acceder a los Datos Personales.</br>
                    c) El servicio de acceso, rectificación y remoción de Datos Personales será prestado por COOKDATA en forma gratuita, excepto en caso de que requiriera un esfuerzo desproporcionado o irrazonable, en cuyo caso podrá cobrarse un cargo de administración.</br>
                    <b>10.2.</b> Asimismo, el Usuario autoriza a COOKDATA a utilizar sus Datos Personales para el envío de comunicaciones y materiales publicitarios (tales como newsletters y folletos) referentes a las actividades de COOKDATA y/o que
                    a exclusivo criterio de esta última pudieran llegar a ser de interés para los Usuarios. Los Usuarios podrán solicitar en cualquier momento la suspensión de dichos envíos.</br>
                    <b>10.3.</b> A fin de ejercer sus derechos, los Usuarios podrán enviar una solicitud a la casilla de correo cookdata@cookdata.io</br>
                    <b>10.4.</b> Asimismo, y ante cualquier eventualidad, se informa al Usuario que como titular de sus Datos Personales tiene la facultad de ejercer el derecho de acceso a los mismos en forma gratuitos en intervalos no inferiores
                    de seis meses, ante las autoridades de aplicación que correspondan, quienes tienen la atribución de atender las denuncias y/o reclamos que se interpongan con relación al incumplimiento de las normas sobre protección de datos personales.</br>
                    <b>10.5.</b> En lo que respecta a los Usuarios que sean ciudadanos de la Unión Europea, éstos podrán ejercer los siguientes derechos frente a COOKDATA:</br>
                    · Acceso. Tiene derecho a acceder a su información para conocer qué Datos Personales en concreto estamos tratando.</br>
                    · Rectificación. Tiene derecho a rectificar aquellos Datos Personales inexactos que estuviéramos tratando.</br>
                    · Supresión. Tiene derecho a solicitar la supresión de aquellos Datos Personales que no desee que sigamos tratando.</br>
                    · Oposición. En determinadas circunstancias, y por motivos relacionados con su situación particular, tiene derecho a oponerse a que tratemos sus Datos Personales, en cuyo caso los mantendremos bloqueados durante el plazo descrito anteriormente.</br>
                    · Limitación del tratamiento. Tiene derecho a solicitar la limitación del tratamiento de sus Datos Personales a aquellas finalidades concretas que desee.</br>
                    · Portabilidad. Tiene derecho a recibir aquellos Datos Personales que nos hubiera facilitado, en un formato estructurado, de uso común y lectura mecánica, y a que se los transmitamos a otro responsable del tratamiento distinto de COOKDATA.</br>
                    Para ejercer cualquiera de ellos deberá proceder al envío de un correo electrónico a COOKDATA a la siguiente dirección cookdata@cookdata.io en el que adjunte una copia de su documento de identidad o Pasaporte.</br>
                    Si lo considera oportuno, el Usuario también puede presentar un reclamo ante la autoridad de control correspondiente.</br>
                    </br>
                    </br>
                    <h2>11. EXCEPCIONES</h2>
                    </br>
                    <b>11.1.</b> No obstante cualquier otra provisión en contrario en la Política de Privacidad, COOKDATA podrá divulgar cierta información personal de los Usuarios, cuando crea de buena fe que esa divulgación resulte razonablemente
                    necesaria para:</br>
                    Evitar una responsabilidad legal;</br>
                    Cumplir una exigencia legal, tal como una orden de allanamiento, una citación o una orden judicial;</br>
                    Cumplir un requerimiento de una autoridad gubernamental o reguladora; y/o</br>
                    Proteger los derechos, propiedad o seguridad de COOKDATA, de los Usuarios, o de un tercero.</br>
                    </br>
                    </br>
                    <h2>12. LÍNEA ETICA/ LÍNEA DE DENUNCIAS</h2>
                    </br>
                    <b>12.1.</b> COOKDATA ofrece al Usuario un canal de comunicación para dar a conocer en forma anónima, confidencial y segura la existencia de irregularidades éticas por parte de cualquier integrante perteneciente a COOKDATA (en
                    adelante, el “Canal de Comunicación”). COOKDATA realiza todas las medidas necesarias a los fines de que dichas irregularidades no ocurran, y debido a ello pone a disposición el Canal de Comunicación posteriormente detallado a los
                    fines de que el Usuario colabore con dicho fin. Para mayor detalle, destacamos a continuación algunos ejemplos de irregularidades de forma enunciativa, a los fines de que el Usuario se mantenga informado:</br>
                    Fraudes económico-financieros.</br>
                    Entrega de información confidencial de la compañía.</br>
                    Conflicto de intereses.</br>
                    Descuido o utilización inapropiada de los bienes de la organización.</br>
                    Uso inapropiado de nombre, logo y marcas de la empresa.</br>
                    Acoso laboral o malos tratos.</br>
                    En el supuesto en que el Usuario contemple una irregularidad de las mencionadas, no debe dudar en reportarla. Su reporte será tratado en forma rápida, confidencial y profesional.</br>
                    <b>12.2.</b> Dicho servicio será brindado por un tercero a los fines de obtener la mayor precisión y objetividad posible. Ello significa que quien tratará los datos personales y/o información brindada por el Usuario una vez que
                    realice una denuncia a través de los Canales de Comunicación detallados posteriormente, serán dichos terceros por cuenta y orden de COOKDATA. El Usuario entiende y acepta que, para los fines de utilizar el Canal de Comunicación,
                    quienes tratarán los datos serán dichos terceros, solo a los efectos de realizar las denuncias y promover un clima ético y de compliance. COOKDATA tratará la presente información denunciada y la remitirá a un Comité, el cual analizará
                    las implicancias de la información y las medidas a tomar.</br>
                    <b>12.3.</b> Debido a lo expuesto, COOKDATA pondrá a disposición de los Usuarios los siguientes Canales de Comunicación:</br>
                    <b>E-mail</b> cookdata@cookdata.io
                    </br>
                    </br>
                    </br>
                    <h2>13. BAJAS, CANCELACIONES, REEMBOLSOS</h2>
                    </br>
                    <b>13.1.</b> Tipos de bajas</br>
                    • Baja por decisión: el inscripto que decide darse de baja de un servicio con previa notificación por escrito a COOKDATA, previo al inicio de la cursada</br>
                    • Baja por incumplimiento si el usuario incurre en faltas al acuerdo establecido, podrá ser dado de baja por COOKDATA.</br>
                    </br>
                    </br>
                    <h2>14. MODIFICACIÓN DE LOS TÉRMINOS Y CONDICIONES.</h2>
                    </br>
                    <b>14.1.</b> COOKDATA podrá modificar los términos y condiciones en cualquier momento. Las nuevas versiones de los términos y condiciones serán notificadas mediante publicación de dicha nueva versión en https://www.cookdata.io/terminos-condiciones
                    y notificada por las vías de contacto que el Usuario declare en su caso.</br>
                    <b>14.2.</b> El Usuario acepta que será dado por notificado de cualquier modificación a los términos y condiciones una vez que COOKDATA hubiera publicado las mismas en [https://www.cookdata.io/terminos-condiciones], y enviado a
                    la notificación por las vías de contacto declaradas por el Usuario. La aprobación de dicha nueva versión, y que la continuación del Usuario en el uso del Servicio una vez publicada la misma dicha nueva versión se considerará como
                    aceptación de dichas modificaciones a los términos y condiciones. Sin perjuicio de lo mencionado, el Usuario acepta chequear https://www.cookdata.io/terminos-condiciones/ periódicamente.</br>
                    </br>
                    </br>
                    <h2>15. CONTACTO</h2>
                    </br>
                    <b>15.1.</b> En caso de que el Usuario tenga alguna duda acerca de los términos y condiciones, o sobre la aplicación de la misma, deberá ponerse en contacto con COOKDATA, en cualquier momento, vía correo electrónico a cookdata@cookdata.io

                </p>
            </div>
        </div>
    </div>
</section>
<!-- termina titulo -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Cookdata-laravel\resources\views/terms/index.blade.php ENDPATH**/ ?>