
<div class="card w-300 h-90 mt-2">  
  <div id="carousel<?php echo e($product->id); ?>" class="carousel slide" data-bs-ride="true">
    <div class="carousel-inner">
      <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
          <img class="d-block w-100 card-img-top" src="<?php echo e(asset($image->path)); ?>" alt="Imagen-del-producto" height="160" >
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <button class="carousel-control-prev btn btn-dark" type="button" data-bs-target="#carousel<?php echo e($product->id); ?>" data-bs-slide="prev" >
      <span class="" aria-hidden="true">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left-square-fill" viewBox="0 0 16 16">
          <path d="M16 14a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12zm-4.5-6.5H5.707l2.147-2.146a.5.5 0 1 0-.708-.708l-3 3a.5.5 0 0 0 0 .708l3 3a.5.5 0 0 0 .708-.708L5.707 8.5H11.5a.5.5 0 0 0 0-1z"/>
        </svg></span>
      <span class="visually-hidden">Previous</span>
    </button>
      
    <button class="carousel-control-next btn btn-dark" type="button" data-bs-target="#carousel<?php echo e($product->id); ?>" data-bs-slide="next" >
      <span class="" aria-hidden="true">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-right-square-fill" viewBox="0 0 16 16">
          <path d="M0 14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2a2 2 0 0 0-2 2v12zm4.5-6.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5a.5.5 0 0 1 0-1z"/>
        </svg>
      </span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>

    <div class="card-body ">
      <h5 class="text-right"><?php echo e($product->title); ?></h5>
      <p class="card-text"><?php echo e($product->description); ?></p>
      <h4 class="card-title">$<?php echo e($product->price); ?></h4>
      <p class="card-text"><?php echo e($product->stock); ?> disponibles</p>
<!-- Si estamos en el carrito no muestra el boton de agregar al carrito y si el de quitar-->
      <?php if(isset($cart)): ?>
      <p class="card-text"><?php echo e($product->pivot->quantity); ?> en tu carrito <strong>$<?php echo e($product->total); ?></strong></p>
        <!-- boton de eliminar del carrito-->
        <form class="d-inline" method="post" action="<?php echo e(route('products.carts.destroy' , ['cart' => $cart->id, 'product' => $product->id])); ?>">
          <?php echo csrf_field(); ?>
          <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">Quitar del carrito</a>
          </form>
        <?php else: ?>
          <!-- boton de agregar al carrito-->
          <form class="d-inline" method="post" action="<?php echo e(route('products.carts.store' , ['product' => $product->id])); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-success">Agregar al carrito</a>
            </form>
        <?php endif; ?>
      
    </div>
  </div>



<?php /**PATH C:\xampp\htdocs\zabit\zabit.store\resources\views/components/product-card.blade.php ENDPATH**/ ?>