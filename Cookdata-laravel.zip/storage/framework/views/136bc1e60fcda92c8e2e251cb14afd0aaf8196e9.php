<div class="row mb-3">
    <label class="col-md-4 col-form-label text-md-end"><?php echo e(__('Perfil')); ?></label>
    <div class="col-md-6">
        <select class="form-select" aria-label="Default select example" name="profile" required>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option  value=""><?php echo e($user->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Cookdata-laravel\resources\views/components/profile-input.blade.php ENDPATH**/ ?>