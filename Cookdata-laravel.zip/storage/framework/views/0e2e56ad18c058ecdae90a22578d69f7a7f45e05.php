

<?php $__env->startSection('content-panel'); ?>
<div class="row justify-content-center">
    <div class="card p-5" style="width: 35rem;">
        <img src="<?php echo e(asset($user->profile_image)); ?>" alt="<?php echo e($user->name); ?>" class="rounded-circle mt-2" width="160" height="160">
        <div class="card-body">
        <h5 class="card-title"><?php echo e($user->name); ?></h5>
        <p class="card-text"><?php echo e($user->email); ?></p>
        <p class="card-text">Empresa:<?php echo e($user->customer->customer); ?></p>
        <p class="card-text">Perfil: <?php echo e($user->profile->profile); ?></p>

        <table class="table">
            <thead>
              <tr>
                <th scope="col">clientes asignados</th>
                <th scope="col">#</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $user->customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>   
                <td><?php echo e($customer->customer); ?></td>              
                    <td>
                        <form action="<?php echo e(route('users.customers.remove', ['userId' => $user->id, 'customerId' => $customer->id])); ?>" method="POST">
                            <button type="submit" class="btn btn-warning btn-sm" title="Eliminar cliente asignado">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16">
                                <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                              </svg></button>
                        </form>
                       
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                   
                
            </tbody>
        </table>


       
      
        
        </div>
    </div>
</div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Cookdata-laravel\resources\views/users/show.blade.php ENDPATH**/ ?>