

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center mt-5 mb-5">
<div class="card mb-3" style="max-width: 540px;">
    <div class="row g-0">
      <div class="col-md-4">
        <img src="<?php echo e(asset(Auth::user()->profile_image)); ?>" alt="<?php echo e(Auth::user()->name); ?>" class="rounded-circle mt-2" width="160" height="160">
      </div>
      <div class="col-md-8">
        <div class="card-body">
          <h5 class="card-title">Nombre: <?php echo e(ucfirst($user->name)); ?></h5>
          <p class="card-text">Correo: <?php echo e(ucfirst($user->email)); ?></p>
          <p class="card-text">Perfil: <?php echo e(ucfirst($user->profile->profile)); ?> </p>
          <div class="navbar navbar-expand-md navbar-light ">
          <ul class="navbar-nav auto">      
            
            <li class="p-3">
                <a href="<?php echo e(route('profile.edit')); ?>">
                <button type="submit" class="btn btn-warning">
                    <?php echo e(__('Editar perfil')); ?>

                </button>
                </a>
            </li>  

            
            </ul>
        </div>
        
        
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Cookdata-laravel\resources\views/profiles/index.blade.php ENDPATH**/ ?>