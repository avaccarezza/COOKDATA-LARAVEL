<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="icon" href="<?php echo e(URL::asset('img/utilities/logo.ico')); ?>"> 
    <title>Zabit</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(URL::asset('img/utilities/logotipo.png')); ?>" width="100px">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/')); ?>">Inicio</a>
                        </li>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">      
                    <!--1- funcion del IF:  muestra el elemento de Panel si el usuario es Admin
                        2- optional() es un helper, que si auth()->user() retorna null la funcion isAdmin() nunca es llamada   --> 
                        <?php if(optional(auth()->user())->isAdmin()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('panel')); ?>" >Panel</a>
                        </li>
                        <?php endif; ?>
                        
                        <?php if(auth()->id() != null): ?>
                        <li class="nav-item">
                            <?php $cartService = app('App\Services\CartService'); ?>
                            <a class="nav-link" href="<?php echo e(route('carts.index')); ?>"><img src="<?php echo e(URL::asset('img/utilities/cart.png')); ?>" alt="shopping-cart" height="32"> (<?php echo e($cartService->countProducts()); ?>)</a>
                        </li>
                        <?php endif; ?>
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Iniciar sesión')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Registrarse')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <img src="<?php echo e(asset(Auth::user()->profile_image)); ?>" alt="<?php echo e(Auth::user()->name); ?>" class="rounded-circle" width="32" height="32">
                                   
                                    <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <div class="card flex-row"><img class="card-img-left example-card-img-responsive rounded-circle m-2" src="<?php echo e(asset(Auth::user()->profile_image)); ?>" alt="<?php echo e(Auth::user()->name); ?>" width="96" height="96"/>
                                        <div class="card-body">
                                          <h4 class="card-title h5 h4-sm"><?php echo e(Auth::user()->name); ?></h4>
                                          <p class="card-text"><?php echo e(Auth::user()->email); ?></p>
                                          <a href="<?php echo e(route('profile.index')); ?>">
                                            <button type="submit" class="btn btn-primary">
                                                <?php echo e(__('Ver perfil')); ?>

                                            </button>
                                            </a>
                                        </div>
                                      </div>
                                  
                                   
                                    <a class="dropdown-item" href="<?php echo e(route('orders_list.index')); ?>"><?php echo e(__('Ver Pedidos')); ?>

                                    </a>
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Cerrar Sesión')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <div class="container-fluid">
                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if(isset($errors) && $errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
                </div>
        </main>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\zabit\zabit.store\resources\views/layouts/app.blade.php ENDPATH**/ ?>