<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Email</title>
</head>
<body>
    
    <p> <strong>Nombre: </strong><?php echo e($contacto['nombre']); ?></p>
    <p> <strong>Email: </strong><?php echo e($contacto['email']); ?></p>
    <p> <strong>Telefono: </strong><?php echo e($contacto['telefono']); ?></p>
    <p> <strong>Tipo de contacto: </strong><?php echo e($contacto['contacto']); ?></p>
    <p> <strong>Empresa: </strong><?php echo e($contacto['empresa']); ?></p>
    <p> <strong>Cargo: </strong><?php echo e($contacto['cargo']); ?></p>
    <p> <strong>Provincia: </strong><?php echo e($contacto['provincia']); ?></p>
    <p> <strong>Población: </strong><?php echo e($contacto['poblacion']); ?></p>
    <p> <strong>Codigo postal: </strong><?php echo e($contacto['codigo_postal']); ?></p>
    <p> <strong>Servicio de interés: </strong><?php echo e($contacto['asunto']); ?></p>
    <p> <strong>Mensaje: </strong><?php echo e($contacto['mensaje']); ?></p>

</body>
</html><?php /**PATH C:\xampp\htdocs\Cookdata-laravel\resources\views/emails/hablemos.blade.php ENDPATH**/ ?>