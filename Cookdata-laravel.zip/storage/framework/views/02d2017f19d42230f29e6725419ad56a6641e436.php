

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
<div class="card mb-3" style="max-width: 540px;">
    <div class="row g-0">
      <div class="col-md-4">
       
      </div>
      <div class="col-md-8">
        <div class="card-body">
          <h5 class="card-title">Nombre: </h5>
          <p class="card-text">Correo: </p>
          <p class="card-text">Telefono: </p>
          <div class="navbar navbar-expand-md navbar-light ">
          <ul class="navbar-nav auto">      
            
            <li class="p-3">
                <a href="<?php echo e(route('profile.edit')); ?>">
                <button type="submit" class="btn btn-primary">
                    <?php echo e(__('Editar perfil')); ?>

                </button>
                </a>
            </li>  

            <li class="p-3">
                <a href="#">
                <button type="submit" class="btn btn-primary">
                    <?php echo e(__('Ver pedidos')); ?>

                </button>
                </li>
                </a>
            </ul>
        </div>
        
        
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zabit\zabit.store\resources\views/order_list/index.blade.php ENDPATH**/ ?>