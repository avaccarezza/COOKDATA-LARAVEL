

<?php $__env->startSection('content'); ?>
    <h1>Detalle del pago</h1>
    <h4 class="text-center"> <strong> Total: </strong> $<?php echo e($order->total); ?></h4>
    <div class="text-center mb-3">
        <form class="d-inline" method="post" action="<?php echo e(route('orders.payments.store', ['order' => $order->id])); ?>">
    <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-success">Pagar</a>
        </form>
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zabit\zabit.store\resources\views/payments/create.blade.php ENDPATH**/ ?>